export const environment = {
  production: true,
  api_url: 'https://gestion-produits-server.herokuapp.com/api'
};
