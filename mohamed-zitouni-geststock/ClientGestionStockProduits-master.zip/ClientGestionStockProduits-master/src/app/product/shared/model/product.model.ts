
export class Product{
  constructor(public id?: number,
              public ref?: string,
              public quantite?: number,
              public prixUnitaire?: number){

  }
}
