
import { Principal } from './model/principal.model';

export interface PrincipalState{
  readonly principal: Principal;
}
