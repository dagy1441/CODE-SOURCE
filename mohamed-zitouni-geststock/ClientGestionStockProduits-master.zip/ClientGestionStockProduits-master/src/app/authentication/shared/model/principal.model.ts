
export class Principal{
  constructor(public authorities: any){
  }
}
