

export class User{
  constructor(
    id?: number,
    username?: string,
    enable?: boolean
  ){}
}
